package functions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class webdriverFunctions {	
	
	
	public static WebDriver driver;
	public static WebElement element;
	
	//Launching browser instance
		public static void lauchBrowser(String browser){
		
		//Method can be developed for all other types of browsers as well
		if(browser.equals("firefox")){
			
			System.setProperty("webdriver.firefox.marionette","C:\\geckodriver.exe");	    	
	    	driver = new FirefoxDriver();
	    	
	    	 driver.manage().window().maximize();
	    	
		}	
	}	
	
	//Opening a praticular URL
	public static void openPage(String url){
		
		driver.get(url);
		
	}
	
	//Typing in a text field
	public static void sendKeys(String id, String input){
		
		driver.findElement(By.xpath(id)).sendKeys(input);
		
	}
		
	//Typing in any field
	public static void type(String id, String input){
		
		driver.findElement(By.xpath(id)).sendKeys(input);
		
	}
	
	//Click on a element
	public static void click(String id){
		
		driver.findElement(By.id(id));
		element.click();
	}
	
	//Click via ID reference
	public static void clickid(String id){
		
		driver.findElement(By.id(id)).click();

	}
	
	//Click on a xpath
	public static void clickXpath(String xpath){
		
		driver.findElement(By.xpath(xpath)).click();

	}
	
	//Hit pagedown button
	public static void pagedown(String input){
		
		driver.findElement(By.xpath(input)).sendKeys(Keys.PAGE_DOWN);

	}
	
	//Hit up button
	public static void up(String input){
		
		driver.findElement(By.xpath(input)).sendKeys(Keys.UP);

	}
	
	//Hit down button
	public static void down(String input){
		
		driver.findElement(By.xpath(input)).sendKeys(Keys.DOWN);

	}
	
	//Hit enter key
	public static void hitEnter(String text){
				
		driver.findElement(By.xpath(text)).sendKeys(Keys.ENTER);

	}
	
	//Hit tab key
	public static void hitTab(String text){
		
		driver.findElement(By.xpath(text)).sendKeys(Keys.TAB);

	}
	
	//Verify text on the page
	public static boolean verifyText(String text){
				
		if(driver.getPageSource().contains(text)) return true;
		
			return false;
			
	}
	
	//Verify text on any element
	public static boolean verifyTextOfElement(String id, String verificationText){
			
		if(driver.findElement(By.xpath(id)).getText().contains(verificationText)) return true;
		
			return false;
			
	}
	
	//Wait for a specified time period
	public static void waitPeriod(long time){
		
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	//Wait for an element to load/appear
	public static void waitForElement(String id, int time){
		
		WebDriverWait wait = new WebDriverWait(driver, time);
		//WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(id)));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(id)));

	}
	
	//Close the browser instance
	public static void closeBrowser(){
		
		driver.close();

	}

}
