package systemTestCases;

import pages.Launch;

//Close the browser instance
public class CleanUp {
	
	boolean result;
	
	public void execute(){
		
		Launch l = new Launch();
		
		//Step 1 : Exit the browser		
		l.closeBrowser();

	}
	

}
