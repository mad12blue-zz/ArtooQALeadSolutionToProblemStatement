package systemTestCases;

import pages.Launch;
import pages.LoginPage;

//Open linkedin login page
public class OpenLinkedinTC {
	
	boolean result;
	
	public boolean execute(){
		
		Launch l = new Launch();
		
		//Step 1 : Launch the browser		
		l.lauchBrowser(main.main.configProp.getProperty("browser"));
		
		//Step 2 : Open the login page
		LoginPage lp = new LoginPage();
		lp.openPage(main.main.configProp.getProperty("url"));
		
		//Step 3 : Verify if page has loaded
    	result = lp.verifyPageLoad(main.main.dataProp.getProperty("launchverification"));
    	
    	//Step 4 : Store Result
    	if(result) return true;
		return false;

	}
	

}
