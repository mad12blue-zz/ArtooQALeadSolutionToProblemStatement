package systemTestCases;

import pages.LoginPage;

//Login to the users linkedin profile
public class LoginTC {
	
	boolean result;
	
	public boolean execute(){
		
		LoginPage lp = new LoginPage();
		
		//Step 1 : Enter username
		lp.enterUsername(main.main.elementProp.getProperty("username"), main.main.dataProp.getProperty("username"));
	
		//Step 2 : Enter password
		lp.enterPassword(main.main.elementProp.getProperty("password"), main.main.dataProp.getProperty("password"));
	
		//Step 3 : Hit signin button
		//lp.clickSignin(main.main.elementProp.getProperty("signin"));	
		lp.hitEnterForSignin(main.main.elementProp.getProperty("signin"));
		
		//Step 4 : Verify if page has loaded
		result = lp.verifyPageLoad(main.main.dataProp.getProperty("loginverification"));
		
		//Step 5 : Store Result
    	if(result) return true;
		return false;
	
	}
	

}
