package systemTestCases;

import pages.SearchPage;

//Follow Artoo company from the search page
public class FollowArtooFromSearchPageTC {
	
	boolean result;
	
	public boolean execute(){
		
		SearchPage sp = new SearchPage();
			
		//Step 1 : Follow Artoo from search page
		sp.followArtooCompany(main.main.elementProp.getProperty("follow"));
		
		//Step 2 : Verify if unfollow text is shown
		sp.waitForMilliSeconds(5000);
		result = sp.verifyUnfollowText(main.main.elementProp.getProperty("follow"),main.main.dataProp.getProperty("unfollow"));
		
		//Step 3 : Store Result
    	if(result) return true;
		return false;
	
	}
	

}
