package systemTestCases;

import pages.ArtooCompanyPage;

//Unfollow Artoo company from the companies search page
public class UnFollowArtooFromCompanyPageTC {
	
	boolean result;
	
	public boolean execute(){
		
		ArtooCompanyPage acp = new ArtooCompanyPage();
			
		//Step 1 : Select Companies
		acp.unfollowArtooCompany(main.main.elementProp.getProperty("unfollow"));
		
		//Step 2 : Verify if companies have loaded
		acp.waitForMilliSeconds(5000);
		result = acp.verifyFollowText(main.main.elementProp.getProperty("unfollow"),main.main.dataProp.getProperty("follow"));
		
		//Step 3 : Store Result
    	if(result) return true;
		return false;
	
	}
	

}
