package systemTestCases;

import pages.SearchPage;

//Search for companies 
public class SearchCompaniesTC {
	
	boolean result;
	
	public boolean execute(){
		
		SearchPage sp = new SearchPage();
			
		//Step 1 : Select Companies
		sp.verifyElementLoad(main.main.elementProp.getProperty("companies"), 10);
		sp.selectCompanies(main.main.elementProp.getProperty("companies"));
		
		//Step 2 : Verify if companies have loaded
		sp.waitForMilliSeconds(5000);
		result = sp.verifyPageLoad(main.main.dataProp.getProperty("companyname"));
		
		//Step 3 : Store Result
    	if(result) return true;
		return false;
	
	}
	

}
