package systemTestCases;

import pages.LogoutPage;

//Logout from the current user linkedin profile
public class LogoutTC {
	
	boolean result;
	
	public boolean execute(){
		
		LogoutPage lo = new LogoutPage();
		
		//Step 1 : Click user dropdown
		lo.clickUser(main.main.elementProp.getProperty("user"));
	
		//Step 2 : Click Signout
		lo.clickSignout(main.main.elementProp.getProperty("signout"));
		
		//Step 4 : Verify if login page has loaded
		lo.waitForMilliSeconds(5000);
		result = lo.verifyPageLoad(main.main.dataProp.getProperty("launchverification"));
		
		//Step 5 : Store Result
    	if(result) return true;
		return false;
	
	}
	

}
