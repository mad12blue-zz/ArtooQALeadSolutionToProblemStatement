package systemTestCases;

import pages.ProfilePage;

//Adding education details to the user profile
public class AddEducationTC {
	
	boolean result;
	
	public boolean execute(){
		
		ProfilePage pp = new ProfilePage();
		
		//Step 1 : Click on Add Education button
		pp.scrollDown(main.main.elementProp.getProperty("addeducation"));
		pp.addEducation(main.main.elementProp.getProperty("addeducation"));
		
		//Step 2 : Add school
		pp.waitForMilliSeconds(2000);
		pp.enterSchool(main.main.elementProp.getProperty("school"), main.main.dataProp.getProperty("school"));
		pp.enter(main.main.elementProp.getProperty("school"));
		
		//Step 3 : Add degree
		pp.waitForMilliSeconds(1000);
		pp.enterDegree(main.main.elementProp.getProperty("degree"), main.main.dataProp.getProperty("degree"));
		pp.enter(main.main.elementProp.getProperty("degree"));
		
		//Step 4 : Add field of study
		pp.waitForMilliSeconds(1000);
		pp.enterField(main.main.elementProp.getProperty("field"), main.main.dataProp.getProperty("field"));
		pp.enter(main.main.elementProp.getProperty("field"));

		//Step 5 : Save Education
		pp.waitForMilliSeconds(1000);
		pp.saveEducation(main.main.elementProp.getProperty("educationsave"));
		
		//Step 6 : verify if Education is saved
		pp.waitForMilliSeconds(3000);
		result = pp.verifyPageLoad(main.main.dataProp.getProperty("school"));

		//Step 7 : Store Result
		if(result) return true;
		return false;
	
	}
	

}
