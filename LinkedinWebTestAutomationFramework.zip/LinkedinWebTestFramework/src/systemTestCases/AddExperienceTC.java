package systemTestCases;

import pages.ProfilePage;

//Adding work experience to the user profile
public class AddExperienceTC {
	
	boolean result;
	
	public boolean execute(){
		
		ProfilePage pp = new ProfilePage();
		
		//Step 1 : Click on Add Experience button
		pp.scrollDown(main.main.elementProp.getProperty("addexperience"));
		pp.addExperience(main.main.elementProp.getProperty("addexperience"));
		
		//Step 2 : Add title
		pp.waitForMilliSeconds(2000);
		pp.enterTitle(main.main.elementProp.getProperty("title"), main.main.dataProp.getProperty("title"));
		pp.enter(main.main.elementProp.getProperty("title"));
		
		//Step 3 : Add company
		pp.waitForMilliSeconds(1000);
		pp.enterCompany(main.main.elementProp.getProperty("company"), main.main.dataProp.getProperty("company"));
		pp.enter(main.main.elementProp.getProperty("company"));
		
		//Step 4 : Add locaiton
		pp.waitForMilliSeconds(1000);
		pp.enterLocation(main.main.elementProp.getProperty("location"), main.main.dataProp.getProperty("location"));
		pp.enter(main.main.elementProp.getProperty("location"));
		
		//Step 4 : Add From Month and Year
		pp.waitForMilliSeconds(1000);
		pp.tab(main.main.elementProp.getProperty("frommonth"));
		pp.down(main.main.elementProp.getProperty("frommonth"));
		pp.tab(main.main.elementProp.getProperty("fromyear"));
		pp.down(main.main.elementProp.getProperty("fromyear"));
		pp.down(main.main.elementProp.getProperty("fromyear"));
		
		//Step 4 : Add To Month and Year
		pp.waitForMilliSeconds(1000);
		pp.tab(main.main.elementProp.getProperty("tomonth"));
		pp.down(main.main.elementProp.getProperty("tomonth"));
		pp.tab(main.main.elementProp.getProperty("toyear"));
		pp.down(main.main.elementProp.getProperty("toyear"));
		
		//Step 5 : Save Experience
		pp.waitForMilliSeconds(1000);
		pp.saveEducation(main.main.elementProp.getProperty("experiencesave"));
		
		//Step 6 : verify if Experience is saved
		pp.waitForMilliSeconds(3000);
		result = pp.verifyPageLoad(main.main.dataProp.getProperty("title"));

		//Step 7 : Store Result
		if(result) return true;
		return false;
	
	}
	

}
