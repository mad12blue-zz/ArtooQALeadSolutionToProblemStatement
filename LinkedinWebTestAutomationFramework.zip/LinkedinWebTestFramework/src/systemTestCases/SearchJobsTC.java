package systemTestCases;

import pages.HomePage;
import pages.SearchPage;

//Search for jobs
public class SearchJobsTC {
	
	boolean result;
	
	public boolean execute(){
		
		HomePage hp = new HomePage();
		SearchPage sp = new SearchPage();
		
		//Step 1 : Enter Company Name to search
		hp.search(main.main.elementProp.getProperty("search"), main.main.dataProp.getProperty("companyname"));
		hp.hitEnterForSearch(main.main.elementProp.getProperty("search"));
	
		//Step 2 : Select Jobs
		sp.verifyElementLoad(main.main.elementProp.getProperty("jobs"), 10);
		sp.selectJobs(main.main.elementProp.getProperty("jobs"));
		
		//Step 4 : Verify if jobs have loaded
		sp.waitForMilliSeconds(5000);
		result = sp.verifyPageLoad(main.main.dataProp.getProperty("job"));
		
		//Step 5 : Store Result
    	if(result) return true;
		return false;
	
	}
	

}
