package systemTestCases;

import pages.HomePage;
import pages.ProfilePage;

//Load the current logged in user profile
public class LoadUserProfileTC {
	
	boolean result;
	
	public boolean execute(){
		
		HomePage hp = new HomePage();
		ProfilePage pp = new ProfilePage();
		
		//Step 1 : Click on the user profile
		hp.loadUserProfile(main.main.elementProp.getProperty("userprofile"));
		
		//Step 2 : verify if the profile has loaded
		pp.waitForMilliSeconds(5000);
		result = pp.verifyPageLoad(main.main.dataProp.getProperty("profileverificatoin"));

		//Step 3 : Store Result
    	if(result) return true;
		return false;
	
	}
	

}
