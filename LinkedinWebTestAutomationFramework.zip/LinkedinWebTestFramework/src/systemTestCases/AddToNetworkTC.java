package systemTestCases;

import pages.ProfilePage;

//Add a user into the current user network
public class AddToNetworkTC {
	
	boolean result;
	
	public boolean execute(){
		
		ProfilePage pp = new ProfilePage();
		
		//Step 1 : Enter user Name to search
		pp.search(main.main.elementProp.getProperty("search"), main.main.dataProp.getProperty("searchname"));
		pp.enter(main.main.elementProp.getProperty("search"));
		
		//Step 2 : View Profile
		pp.waitForMilliSeconds(3000);
		pp.clickUser(main.main.elementProp.getProperty("madhan"));
			
		//Step 6 : verify if Profile is seen
		pp.waitForMilliSeconds(3000);
		result = pp.verifyPageLoad(main.main.dataProp.getProperty("profileverificaiton"));

		//Step 7 : Store Result
		if(result) return true;
		return false;
	
	}
	

}
