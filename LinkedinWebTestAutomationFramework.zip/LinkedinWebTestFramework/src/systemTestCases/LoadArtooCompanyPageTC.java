package systemTestCases;

import pages.ArtooCompanyPage;
import pages.SearchPage;

//Load Artoo company page from the search result
public class LoadArtooCompanyPageTC {
	
	boolean result;
	
	public boolean execute(){
		
		SearchPage sp = new SearchPage();
		ArtooCompanyPage acp = new ArtooCompanyPage();
			
		//Step 1 : Select Companies
		sp.selectArtooCompany(main.main.elementProp.getProperty("artoocompany"));
		
		//Step 2 : Verify if companies have loaded
		sp.waitForMilliSeconds(5000);
		result = acp.verifyPageLoad(main.main.dataProp.getProperty("companyname"));
		
		//Step 3 : Store Result
    	if(result) return true;
		return false;
	
	}
	

}
