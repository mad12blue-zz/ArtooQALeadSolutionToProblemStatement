package main;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import orchestrator.Orchestrate;
import reporting.Log;
import reporting.Report;

public class main {
	
	public static Properties configProp, suiteProp, keysProp, dataProp, elementProp;

	
	public static void main(String[] args) {
		
		//Initializing all properties
		
		configProp = new Properties();
		InputStream configInput = null;
		
		suiteProp = new Properties();
		InputStream suiteInput = null;
		
		keysProp = new Properties();
		InputStream keysInput = null;
		
		dataProp = new Properties();
		InputStream dataInput = null;
		
		elementProp = new Properties();
		InputStream elementInput = null;

		try {

			//Reading the property files
			
			configInput = new FileInputStream("Properties\\config.properties");
			configProp.load(configInput);
			
			suiteInput = new FileInputStream("Properties\\suite.properties");
			suiteProp.load(suiteInput);
			
			elementInput = new FileInputStream("Properties\\element.properties");
			elementProp.load(elementInput);
			
			dataInput = new FileInputStream("Properties\\data.properties");
			dataProp.load(dataInput);

			if(suiteProp.getProperty("executionType").equals("keyword")){
				
				keysInput = new FileInputStream("Properties\\keys.properties");
				keysProp.load(keysInput);		
				
				Orchestrate cr = new Orchestrate();
				//Start of Test execution
				cr.executeKeyword();	
				
				//Display logs on console
				Log.displayResult();
				
				//Generating report
				Report.generateReport();
				
			}
			
		} catch (Exception e) {

					e.printStackTrace();
		}
    	
    }

}