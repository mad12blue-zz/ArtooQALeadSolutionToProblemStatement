package orchestrator;

import reporting.Log;
import systemTestCases.AddEducationTC;
import systemTestCases.AddExperienceTC;
import systemTestCases.AddToNetworkTC;
import systemTestCases.CleanUp;
import systemTestCases.FollowArtooFromSearchPageTC;
import systemTestCases.LoadArtooCompanyPageTC;
import systemTestCases.LoadUserProfileTC;
import systemTestCases.LoginTC;
import systemTestCases.LogoutTC;
import systemTestCases.OpenLinkedinTC;
import systemTestCases.SearchCompaniesTC;
import systemTestCases.SearchJobsTC;
import systemTestCases.UnFollowArtooFromCompanyPageTC;

public class Orchestrate {
	
	
	public void executeKeyword(){
		
		String seq = main.main.keysProp.getProperty("sequence");
		
		String [] seqArr = seq.split(",");
		
		System.out.println("*****************************BEGIN TEST EXECUION*****************************");
		
		for(int i = 0; i < seqArr.length; i++){
			
		//Swiych Statement to execute the test cases mentioned in the keys.properties
			
			System.out.println("---Executing Test Case \t:\t '"+seqArr[i]+"");
			
			 switch(seqArr[i]){  
			 
			    case "OpenLinkedin": 			    			    	
			    	OpenLinkedinTC ol = new OpenLinkedinTC();				    	
			    	Log.storeResult("Open", ol.execute());
			    	break;  
			    	
			    case "Login": 
			    	
			    	LoginTC log = new LoginTC();
			    	Log.storeResult("Login", log.execute());
			    	break;  
			    	
			    case "SearchJobs": 
			    	
			    	SearchJobsTC sa = new SearchJobsTC();
			    	Log.storeResult("SearchJobs", sa.execute());
			    	break; 
			    	
			    case "SearchCompanies": 
			    	
			    	SearchCompaniesTC sc = new SearchCompaniesTC();
			    	Log.storeResult("SearchCompanies", sc.execute());
			    	break;
			    	
			    case "FollowArtooFromSearchPage": 
			    	
			    	FollowArtooFromSearchPageTC fa = new FollowArtooFromSearchPageTC();
			    	Log.storeResult("FollowArtooFromSearchPage", fa.execute());
			    	break;
			    	
			    case "LoadArtooCompanyPage": 
			    	
			    	LoadArtooCompanyPageTC lc = new LoadArtooCompanyPageTC();
			    	Log.storeResult("LoadArtooCompanyPage", lc.execute());
			    	break;
			    	
			    case "UnFollowArtooFromCompanyPage": 
			    	
			    	UnFollowArtooFromCompanyPageTC ua = new UnFollowArtooFromCompanyPageTC();
			    	Log.storeResult("UnFollowArtooFromCompanyPage", ua.execute());
			    	break;
			    	
			    	
			    case "Logout": 
			    	
			    	LogoutTC lo = new LogoutTC();
			    	Log.storeResult("Logout", lo.execute());
			    	break;
			    
			    case "UserProfile": 
			    	
			    	LoadUserProfileTC up = new LoadUserProfileTC();
			    	Log.storeResult("UserProfile", up.execute());
			    	break;
			    	
			    case "AddEducation": 
			    	
			    	AddEducationTC ae = new AddEducationTC();
			    	Log.storeResult("AddEducation", ae.execute());
			    	break;
			    	
			    case "AddExperience": 
			    	
			    	AddExperienceTC aex = new AddExperienceTC();
			    	Log.storeResult("AddExperience", aex.execute());
			    	break;
			    	
			    case "AddToNetwork": 
			    	
			    	AddToNetworkTC an= new AddToNetworkTC();
			    	Log.storeResult("AddToNetwork", an.execute());
			    	break;
			    	
			    case "CleanUp": 
			    	
			    	CleanUp cu= new CleanUp();
			    	cu.execute();
			    	break;
			    	
			 }
						
		 }
		
		System.out.println("*****************************END TEST EXECUION*****************************");
		
	}
	

}
