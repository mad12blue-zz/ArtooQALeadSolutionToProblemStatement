package pages;

import functions.webdriverFunctions;

public class Launch {
	
	//Launch Browser
	public void lauchBrowser(String browser){
		
    	webdriverFunctions.lauchBrowser(browser); 

	}
	
	//Close Browser
	public void closeBrowser(){
		
    	webdriverFunctions.closeBrowser();

	}
	

}
