package pages;

import functions.webdriverFunctions;


public class LoginPage {
	
	//Open the login page
	public void openPage(String url){
	   	
    	webdriverFunctions.openPage(url);
	}
	
	//Verify if login page has loaded
	public boolean verifyPageLoad(String verificationText){
		
    	return webdriverFunctions.verifyText(verificationText);
	}
	
	//Enter username in the username field
	public void enterUsername(String objectID, String value){
	   	
    	webdriverFunctions.sendKeys(objectID, value);
	}
	
	//Enter password in the password field
	public void enterPassword(String objectID, String value){
	   	
    	webdriverFunctions.sendKeys(objectID, value);
	}
	
	//Click on Sign in button
	public void clickSignin(String objectID){
	   	
    	webdriverFunctions.clickid(objectID);
	}
	
	//Hit Enter for sign in
	public void hitEnterForSignin(String objectID){
	   	
    	webdriverFunctions.hitEnter(objectID);
	}
		

}
