package pages;

import functions.webdriverFunctions;


public class LogoutPage {
	
	//Click on User profile
	public void clickUser(String objectID){
	   	
    	webdriverFunctions.clickXpath(objectID);
	}
	
	//Click on Signout button
	public void clickSignout(String objectID){
	   	
    	webdriverFunctions.clickXpath(objectID);
	}
	
	//Verify if logged out screen has loaded
	public boolean verifyPageLoad(String verificationText){
		
    	return webdriverFunctions.verifyText(verificationText);
	}
	
	//Wait for the page to load
	public void waitForMilliSeconds(long time){
		
		webdriverFunctions.waitPeriod(time);
	}		

}
