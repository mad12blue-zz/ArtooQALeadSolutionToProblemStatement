package pages;

import functions.webdriverFunctions;


public class ArtooCompanyPage {

	//Verify if Company page has loaded	
	public boolean verifyPageLoad(String verificationText){
		
    	return webdriverFunctions.verifyText(verificationText);
	}
	
	//Verify if a particular element on Company page has loaded
	public void verifyElementLoad(String objectID, int waitTime){
		
    	webdriverFunctions.waitForElement(objectID, waitTime);
	}
	
	//Wait for an object to load
	public void waitForMilliSeconds(long time){
		
		webdriverFunctions.waitPeriod(time);
	}
	
	//Hit Unfollow button on the company page
	public void unfollowArtooCompany(String objectID){
		
		webdriverFunctions.clickXpath(objectID);
	}

	//Verify if follow text is shown
	public boolean verifyFollowText(String ObjectID, String verificationText){
		
    	return webdriverFunctions.verifyTextOfElement(ObjectID, verificationText);

	}
		

}
