package pages;

import functions.webdriverFunctions;


public class ProfilePage {
	
	//Verify if Profile has loaded
	public boolean verifyPageLoad(String verificationText){
		
    	return webdriverFunctions.verifyText(verificationText);
	}
	
	//Wait for Profile to load
	public void waitForMilliSeconds(long time){
		
		webdriverFunctions.waitPeriod(time);
	}
	
	//Click on Add Educaiton button
	public void addEducation(String objectID){
	   	
    	webdriverFunctions.clickXpath(objectID);
	}
	
	//Click on Add Experience button
	public void addExperience(String objectID){
	   	
    	webdriverFunctions.clickXpath(objectID);
	}
	
	//Scroll down on the Profile page
	public void scrollDown(String objectID){
	   	
    	webdriverFunctions.pagedown(objectID);
	}
	
	//Hit enter button after entering details
	public void enter(String objectID){
	   	
    	webdriverFunctions.hitEnter(objectID);
	}
	
	//Hit tab button to navigate to next field
	public void tab(String objectID){
	   	
    	webdriverFunctions.hitTab(objectID);
	}
	
	//Hit down button to select a item
	public void down(String objectID){
	   	
    	webdriverFunctions.down(objectID);
	}
	
	//Enter schooling information
	public void enterSchool(String objectID, String value){
	   	
    	webdriverFunctions.sendKeys(objectID, value);
	}
	
	//Enter the job title
	public void enterTitle(String objectID, String value){
	   	
    	webdriverFunctions.sendKeys(objectID, value);
	}
	
	//Enter the Degree obtained
	public void enterDegree(String objectID, String value){
	   	
    	webdriverFunctions.sendKeys(objectID, value);
	}
	
	//Enter company details
	public void enterCompany(String objectID, String value){
	   	
    	webdriverFunctions.sendKeys(objectID, value);
	}
	
	//Enter field of expertise
	public void enterField(String objectID, String value){
	   	
    	webdriverFunctions.sendKeys(objectID, value);
	}
	
	//Enter location details
	public void enterLocation(String objectID, String value){
	   	
    	webdriverFunctions.sendKeys(objectID, value);
	}
	
	//Enter the month from when the job was started
	public void enterFromMonth(String objectID, String value){
	   	
    	webdriverFunctions.sendKeys(objectID, value);
	}
	
	//Save education details entered
	public void saveEducation(String objectID){
	   	
    	webdriverFunctions.clickXpath(objectID);
	}
	
	//Search for a particular item
	public void search(String ObjectID, String text){
	   	
    	webdriverFunctions.type(ObjectID, text);
	}
	
	//Click on the user profile
	public void clickUser(String ObjectID){
	   	
    	webdriverFunctions.clickXpath(ObjectID);
	}	

}
