package pages;

import functions.webdriverFunctions;


public class HomePage {
	
	//Search for any item on home page
	public void search(String ObjectID, String text){
	   	
    	webdriverFunctions.type(ObjectID, text);
	}

	//Hit enter for searching in the home page
	public void hitEnterForSearch(String objectID){
	   	
    	webdriverFunctions.hitEnter(objectID);
	}
		
	//Load the current user profile
	public void loadUserProfile(String objectID){
	   	
    	webdriverFunctions.clickXpath(objectID);
	}

}
